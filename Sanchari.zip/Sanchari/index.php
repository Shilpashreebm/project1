<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}
.heading{
font-size: 47px;
color:white;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
.para{
    color=balck;
    font-size: 30px;
    text-align: center;
}
.imaf{
   width: 150px;
   height: 150px;
}
</style>
</head>
<body style="background-color:powderblue;">
<div class="topnav">
  <p class="heading">Online Ambulance</p>
  <a  href="index.php">Home</a>
  <a href="about.php">About Us</a>
  <a href="user/login.php">Login</a>
  <a href="user/registerform.php">Signup</a>
</div>
 <p class="para">Ambulance place a very crucial role when an accident occurs on<br/>
        the road network or in case of any medical emergency and the need<br/>
arises to save a human life. In this project an web application namely<br/>
Online Ambulance Booking Service has been developing. It’s a<br/><!-- comment -->
unique idea in itself in which one can book an ambulance using web<br/>
application.<!-- comment -->
    So Register now
   <br/><!-- comment -->
   <img class="imaf" src="am2.jfif"><br /><!-- comment -->
   <button><strong>Sing-up</strong></button></p>
    

</body>
</html>
